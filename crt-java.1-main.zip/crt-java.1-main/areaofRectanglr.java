public class Main

{
	
public static void main(String[] args)
	
{
	  
  int a,b,c;
	    
a=2;
	    
b=3;
	   
 c=a*b;
		
System.out.println("length*breadth="+c);
	
}

}
