import java.util.*;

public class Main

{
	
public static void main(String[] args)
	
{
	   
int a,b,c;
	    
Scanner s=new Scanner(System.in);
	    System.out.println("enter the length and breadth");
	    a=s.nextInt();
	    
b=s.nextInt();
	   
 c=a*b;
		
System.out.println("area of rectangle="+c);
	
}

}
