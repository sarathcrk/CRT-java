import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner s=new Scanner(System.in);
	    int i,n;
	    n=s.nextInt();
	    for(i=2;i<=n;i=i+2)
	    {
		System.out.println(i+"");
	}
}
}
