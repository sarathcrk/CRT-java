import java.util.*;
public class Big
{
	public static void main(String[] args)
	{
	  Scanner s=new Scanner(System.in);
	  int a,b;
	  System.out.println("Enter two num");
	  a=s.nextInt();
	  b=s.nextInt();
	  if(a>b)
	  {
	      System.out.println(a+"is Bigger");
	  }
	  else
	  {
	      System.out.println(b+"is Bigger");
	  }  
	}
}
