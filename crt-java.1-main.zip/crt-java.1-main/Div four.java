import java.util.*;

public class Main

{
	
public static void main(String[] args)
	
{
	    
int a,b,c,d,e;
	  
  a=500;
	    
b=a/4;
	   
 c=a/4;
	   
 d=a/4;
	    
e=a/4;
	   
Scanner s=new Scanner(System.in);
	   System.out.println("first="+b);
	  
 System.out.println("second="+c);
	   System.out.println("third="+d);
	   
System.out.println("fourth="+e);
	
}

}	
