import java.util.*;
public class Main

{
	
public static void main(String[] args)
	
{
	  
 Scanner s=new Scanner(System.in);
	  
 double p,t,r,i;
	  
 System.out.println("enter principle");
	   p=s.nextDouble();
	  
 System.out.println("enter time");
	   t=s.nextDouble();
	  
 System.out.println("enter rate");
	   r=s.nextDouble();
	 
  i=p*t*r/100;
	
System.out.println("Hello World"); 
	System.out.println("INTREST="+i);
	
}

}
