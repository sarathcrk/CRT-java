import java.util.*;
public class Series
{
	public static void main(String[] args) 
	{
	    Scanner s=new Scanner(System.in);
	    int i,n,n1=0;
	    n=s.nextInt();
	    for(i=1;i<=n;i++)
	    {
	        System.out.println(n1+"");
	    n1=n1+i;
	    }
	}
}
